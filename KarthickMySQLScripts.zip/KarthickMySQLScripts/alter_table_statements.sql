 create table test3(
 id int,
 name text
);

desc test3;

alter table test3 add age int;
desc test3;

alter table test3 add (doj date, salary double);
desc test3;

alter table test3 drop doj;
desc test3;

alter table test3 modify column salary int;
desc test3;