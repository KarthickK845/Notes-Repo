create table test1(
id		int,
age		int,
grade	char(1));

insert into test1 values(1,20,'A');
insert into test1 values(2,25,'B');
insert into test1 values(3,26,'A');

select * from test1;

start transaction;
insert into test1 values(4,46,'C');
select * from test1;
update test1 set age=30 where id=1;
select * from test1;
rollback;  -- revert some changes

start transaction;
insert into test1 values(4,46,'C');
update test1 set age=30 where id=1;
select * from test1;
commit;   -- save the changes to table

-- below is alternative way to start transaction
set autocommit = 0;
set autocommit = off;
-- after above and inserting some data, it will not commit immediately
-- we will have the option to rollback after inserting the records which will remove the data from table

-- by default, all DML statements are auto-commit
-- we can set OFF by using above