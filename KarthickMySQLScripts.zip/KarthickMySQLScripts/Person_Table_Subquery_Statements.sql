describe persons;

select  * from persons;

select country,sum(salary) from persons group by country;
select gender,sum(salary) from persons group by gender;
select city,sum(salary) from persons group by city;

select country,min(salary) from persons group by country;
select country,count(salary) from persons group by country;
select country,avg(salary) from persons group by country;

-- to filter the records based on aggregate function values
select country,count(salary) from persons group by country having country='India';

select count(pid) as Indians_Count from persons group by country having country='India';
select sum(salary) as US_Total_Salary from persons group by country having country='USA';
select count(pid) as Male_count from persons group by gender having gender = 'M';
select count(pid) as Female_count from persons group by gender having gender = 'F';

select avg(salary) from persons;
select name, salary from persons where salary>(select avg(salary) from persons);

select name,salary,country
from persons
where country in ('USA','UK');