package com.ust.ui;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HelloController {
	
	@GetMapping("/hello")
	public String f1(Model model) {
		System.out.println("f1");
		model.addAttribute("message", "Welcome to Spring Boot World !!!");
		return "hello";
	}
}
