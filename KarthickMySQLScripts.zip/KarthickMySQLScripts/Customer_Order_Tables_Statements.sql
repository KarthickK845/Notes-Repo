create table customers(
customer_id int,
customer_name text(50),
customer_email	text(50),
customer_phone	text(50));

create table orders(
order_id	int auto_increment primary key,
order_date	date,
order_amount	double,
customer_id		int);

insert into customers
(customer_id, customer_name, customer_email,customer_phone)
values (101,'Meghna','meghna@gmail.com',6656784908);

insert into customers values (102, 'Surya','surya@gmail.com',9899874353);
insert into customers values(103,'Mahesh','mahesh@gmail.com',7787665654);
insert into customers values(104,'Murugan','murugan@gmail.com',8776843211);
insert into customers values(105,'Murugesh','murugesh@gmail.com',9985430431);

select * from customers;

insert into orders (order_date,order_amount,customer_id)
values('2022-09-14',12340.0,101);
insert into orders (order_date,order_amount,customer_id)
values('2022-07-24',18440.0,101);

insert into orders (order_date,order_amount,customer_id)
values('2021-10-04',2340.0,102);
insert into orders (order_date,order_amount,customer_id)
values('2022-01-11',5040.0,102);

insert into orders (order_date,order_amount,customer_id)
values('2021-04-12',10000.0,104);
insert into orders (order_date,order_amount,customer_id)
values('2021-05-14',9340.0,104);

insert into orders (order_date,order_amount,customer_id)
values('2020-03-04',3400.0,105);
insert into orders (order_date,order_amount,customer_id)
values('2020-04-24',3480.0,105);

insert into orders (order_date,order_amount,customer_id)
values('2023-10-10',6740.0,106);
insert into orders (order_date,order_amount,customer_id)
values('2023-11-15',5340.0,106);

select * from orders;

-- join tables
-- below query gives 50 records i.e. 5 in Customers and 10 in Orders => 5 X 10
select * from customers, orders ;
-- one way of joining

-- below query where only common records from both tables will be fetched
select * from customers, orders where customers.customer_id=orders.customer_id;

-- inner join based 'on the condition', only common records
select 
	c.customer_id, 	c.customer_name, c.customer_email, 	c.customer_phone,
    o.order_id,     o.order_date,    o.order_amount,    o.customer_id
from 
	Customers c inner join Orders o
on
	c.customer_id=o.customer_id;
    
-- left join to include all records from left table even though it doesn't match with right table
select 
	c.customer_id, 	c.customer_name, c.customer_email, 	c.customer_phone,
    o.order_id,     o.order_date,    o.order_amount,    o.customer_id
from 
	Customers c left join Orders o
on
	c.customer_id=o.customer_id;
    
-- right join to include all records from right table even though it doesn't match with left table
select 
	c.customer_id, 	c.customer_name, c.customer_email, 	c.customer_phone,
    o.order_id,     o.order_date,    o.order_amount,    o.customer_id
from 
	Customers c right outer join Orders o
on
	c.customer_id=o.customer_id;