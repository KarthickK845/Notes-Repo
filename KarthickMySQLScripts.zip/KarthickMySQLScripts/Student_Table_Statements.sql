create table students1(
rollnumber integer primary key,
name varchar(50) not null,
emailid varchar(50) unique
);

insert into students1(rollnumber,name,emailid) values(101,'Arun','arun@gmail.com');
insert into students1(rollnumber,name,emailid) values(102,'Mano','mano@gmail.com');
insert into students1(rollnumber,name,emailid) values(103,'Ganga','ganga@gmail.com');
insert into students1(rollnumber,name,emailid) values(104,'Shakuntala','shakuntala@gmail.com'); -- name can't be left blank
insert into students1(rollnumber, name, emailid) values(105,'Manga','manga@gmail.com');

create table students1_marks1(
id 			integer primary key,
rollnumber 	integer references students1(rollnumber),  -- foreign key
subject 	varchar(50),
mark		integer check (mark>=0 and mark<=100) -- constraint to accept only the values in this range
);

-- another way of creating constraints at table level, specifying after table structure
-- but we cannot specify 'not null, unique' constraints like this
-- also this way of foreign key constraint is working, students1_marks1 is not correct way to specify foreign key constraint
create table students1_marks2(
id integer,
rollnumber 	integer ,  -- foreign key
subject varchar(50),
mark	integer, -- constraint to accept only the values in this range
primary key (id),
foreign key(rollnumber)references students1(rollnumber),
check (mark>=0 and mark<=100)
);
describe students1_marks1;
insert into students1_marks1 values(5001,101,'Maths',96);
insert into students1_marks1 values(5002,101,'Physics',78);
insert into students1_marks1 values(5003,107,'Chemistry',68);

drop table students1_marks1;

-- we will use students1_marks2 and students1_marks3
insert into students1_marks2 values(5001,102,'Maths',96);
insert into students1_marks2 values(5002,102,'Physics',78);
insert into students1_marks2 values(5003,107,'Chemistry',68);

select * from students1_marks1;

create table students1_marks3(
id integer,
rollnumber 	integer ,
subject varchar(50),
mark	integer,
constraint mark_id_pk primary key (id),
constraint rollnumber_fk foreign key(rollnumber) references students1(rollnumber),
constraint mark_range_check check (mark>=0 and mark<=100)
);
-- naming constraint
-- sql will display the specified constraint name if we violate that constraint

describe students1_marks3;
select * from students1_marks3;