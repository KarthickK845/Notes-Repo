use trainingdb21;

show tables;

create table Products(
	id 		int,
    name	text,
    price	double
);

select * from Products;

delete from products where id=104;

create table loans(
	id		int,
    customerName		text,
    loanAmount		double,
    tenure	int
);

select * from loans;