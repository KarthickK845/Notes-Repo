delimiter //
create function year_difference(p1 date)
	returns int deterministic
begin
	-- declare difference year;
	-- select year(curdate(), dob) into difference from persons;
    -- return difference;
    
    declare date2 date;
    select curdate() into date2;
    return year(date2)-year(p1);
end //
delimiter ;

select year_difference(dob) from persons;

use trainingdb19;