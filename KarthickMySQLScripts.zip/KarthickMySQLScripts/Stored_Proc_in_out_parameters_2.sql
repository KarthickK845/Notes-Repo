delimiter //
create procedure incrementSalary
(IN countryName text(50), IN per int, OUT tot double)
begin
	update persons set salary=(salary+(salary*per/100)) where country = countryName;
    select sum(salary) into tot from persons where country=countryname;
end//
delimiter ;

call incrementSalary('USA',5,@total);

select @total;

select * from persons;
