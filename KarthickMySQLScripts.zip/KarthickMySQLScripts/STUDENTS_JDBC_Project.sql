create table students(
	ROLLNUMBER INT,
    NAME		TEXT(50),
    GENDER		CHAR(1),
    MARK1		INT,
    MARK2		INT,
    CONSTRAINT STUDENTS_RN_PK primary key(rollnumber),
    constraint students_gender_check check(GENDER='M' OR GENDER='F'),
    constraint students_mark1_check check(MARK1>=0 AND MARK1<=100),
    constraint students_mark2_check check(MARK2>=0 AND MARK2<=100)
);

desc students;

select * from students;