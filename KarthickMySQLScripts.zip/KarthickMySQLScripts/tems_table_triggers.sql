create table items(
id	int 	auto_increment	 primary key,
name 	text,
price	double);

insert into items(name,price) values('DELL',35000.00);
insert into items(name,price) values('ACER',65000.00);

select * from items;

create table items_logs(
id int auto_increment primary key,
name text,
type text,
created_time datetime);

-- TRIGGER : ITEM BEFORE INSERT
delimiter //
create trigger itemBeforeInsert
before insert
on items for each row
begin
	if new.price<0
		then set new.price=0;
	end if;
end//
delimiter ;

insert into items(name,price) values('LENOVO',-45000.00);
insert into items(name,price) values('ASUS',54000.00);
insert into items(name,price) values('INTEX',-14000.00);

drop trigger itemBeforeInsert;

-- TRIGGER : ITEM AFTER INSERT
delimiter //
create trigger itemAfterInsert
after insert
on items for each row
begin
	declare temp datetime;
    set temp = now();
    insert into items_logs(name,type,created_time) values(new.name,"Insert",temp);
end//
delimiter ;

select * from items_logs;

-- TRIGGER : ITEM AFTER DELETE
delimiter //
create trigger itemAfterDelete
after delete
on items for each row
begin
	declare temp datetime;
    set temp = now();
    insert into items_logs(name,type,created_time) 
    values(old.name,"Delete",temp);
end//
delimiter ;

delete from items where name='LENOVO';

-- TRIGGER : ITEM AFTER UPDATE
delimiter //
create trigger itemAfterUpdate
after update
on items for each row
begin
	declare temp datetime;
    set temp = now();
    insert into items_logs(name,type,created_time) 
    values(old.name,"Update",temp);
end//
delimiter ;

update items set price=99000.00 where name = 'ASUS';