create table customers_1(
customer_id int,
customer_name text(50),
balance		double,
email	text(50),
phone_number	text(20),
constraint customer_id_pk primary key(customer_id),
constraint customer_balance_check check(balance>0),
constraint customer_phone_check check(length(phone_number)=10)
);

desc customers_1;

select * from customers_1;