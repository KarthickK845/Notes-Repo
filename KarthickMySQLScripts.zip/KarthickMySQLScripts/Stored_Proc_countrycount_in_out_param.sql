use trainingdb19;

-- in parameter countryname
-- out parameter counter (getting the count of persons in a countryname)

delimiter //
create procedure countrycount(IN countryname varchar(50), OUT counter int)
begin
	SELECT count(*) into counter from persons WHERE country=countryname;
end//
delimiter ;

call countrycount('USA',@cnt);  -- to retrieve/access the out parameter, we use '@' with the variable
select @cnt;

    