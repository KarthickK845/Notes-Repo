-- writing a program logic inside a stored procedure

-- creating the stored procedure
-- changing the delimiter from ; to // in the below procedure
delimiter //		

create procedure printAge()
begin
	declare age int;
    set age = 20;
    select age;
end //

delimiter ;

-- calling the procedure
call printAge();

-- delete procedure
drop procedure printAge;