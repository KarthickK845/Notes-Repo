create table PERSONS(
PID	integer primary key,
NAME VARCHAR(50),
DOB date,
SALARY double,
GENDER char,
CITY varchar(40),
COUNTRY varchar(40)
);

insert into PERSONS values(101, 'Bakshi', '1995-09-09',34000.00,'M','Delhi','India');
insert into PERSONS values(102, 'Beena', '1991-08-29',24000.00,'F','London','UK');
insert into PERSONS values(103, 'Tina', '1980-05-19',56000.00,'F','Kolkata','India');
insert into PERSONS values(104, 'Monica', '1994-11-08',74000.00,'F','NewYork','USA');

insert into PERSONS values(105, 'Frank', '1967-06-19',80000.00,'M','SanJose','USA');
insert into PERSONS values(107, 'Joseph', '1971-07-29',44000.00,'M','Arizona','USA');
insert into PERSONS values(106, 'Rani', '1970-05-18',77000.00,'F','Kolkata','India');
insert into PERSONS values(108, 'Ross', '1993-11-08',64000.00,'M','NewYork','USA');

insert into PERSONS values(109, 'Rahul', '1970-05-18',77000.00,'M','Liverpool','UK');
insert into PERSONS values(110, 'Gunther', '1973-10-09',54000.00,'M','Chicago','USA');

insert into PERSONS values(112, 'Janice', '1969-08-29',30000.00,'F','Philadelphia','USA');
insert into PERSONS values(111, 'Kumar', '1972-03-20',14000.00,'M','Kanpur','India');
insert into PERSONS values(113, 'Shreya', '1984-05-18',95000.00,'F','Jaipur','India');
insert into PERSONS values(114, 'Rachel', '1987-11-28',34000.00,'F','Washington','USA');
insert into PERSONS values(115, 'Judy', '1965-12-19','83000.00','F','LosAngeles','USA');

select * from PERSONS;

select name,dob,salary from persons;
select name,dob,salary+100 from persons;

-- built in functions : String functions
select ascii('A');
select ascii(gender) from persons;
select char_length('abcd');
select name, char_length(name) from persons;
select concat('abc','xyz');
select concat(name, ' ',country) as name_country from persons;
select concat_ws('-',name,country) from persons;
select format(12345.987,2);   -- result : 12,345.99
select format(salary,2) from persons;
select insert('welcome to my world',3,10,"to my sql"); -- insert into first string at position 3
select instr('welcome to my world','my');    -- find position of the string 'my'
select lcase(name),country,Lcase(country) from persons;   -- country in lower case
select left("welcome to my world",5); -- extract 5 chars from left of the given string
select left(name,3) from persons;
select length('welcome');
select length(name),length(country) from persons;
select lower(country) from persons;  -- lower case of country
select lpad(name, 30, "abc ") from persons; -- total 30 chars out of which most of the cahrs filled with 'abc ' and then the name values
select length("       welcome to my world");
select length(ltrim("       welcome to my world")); -- length of the string after trimming space
select mid("Welcome to my world !!", 5,3); -- 3 chars from 5 th position
select position("world" IN "Welcome to my World "); -- returns postion of world case insensitive
select repeat("Java ",10); -- repeat Java 10 times
select name, repeat(name,3) from persons; -- repeat name 3 times
select replace("who are you?","who","how"); -- replace who with how
select reverse('who');
select country, reverse(country) from persons;
select right("welcome to my worl",4);  -- extract 4 chars from the right side
select right(name,4) from persons; -- 4 chars of name from left
select rpad(name,50,"Abc ") from persons; -- opp to lpad, total 50 chars
select rtrim("welcome to my world      ");  -- removes trailing space
select concat(name,space(10),country) from persons;    -- creates 10 empty spaces concats with name and country
select strcmp("abc","xyz"); -- returns -1 or 1 if not equal else 0
select substr("Welcome to my world",5,3);
select substr("Welcome to my world" from 5 for 6);
select substring("Welcome to my world",5,5);
select trim("   welcome   ");
select ucase(name) from persons;
select upper(name) from persons;

-- built in functions : Numeric functions
select abs(45-55); -- find difference and prints the absolute value (without sign)
select avg(salary) from persons; -- average of salary
select min(salary) from persons;
select max(salary) from persons;
select count(salary) from persons; -- count of non null values only printed, doesn't count null

select ceil(45.75);
select ceiling(45.75); -- returns next adjacent integer 46
select count(name) from persons;

select 10 div 5;
select exp(2); -- exponential
select floor(25.75); -- return previous adjacent integer
select greatest(3,12,24,5);
select least(3,12,24,5);
select pow(4,5);
select power(4,2);
select rand();  -- random decimal values between 0 and 1
select round(135.375,2); -- rounds off to two decimal values
select sqrt(64);
select truncate(135.375,2);

select curdate();
select current_date();
select current_time();
select current_timestamp();
select curtime();

select date(dob) from persons;
select date("2017-06-15 09:34:21");
select datediff(dob, curdate()) from persons;
select datediff(curdate(),dob) from persons;
select datediff(curdate(),'2025-03-07') from persons;

select date_add('2024-06-15',INTERVAL 10 DAY);
select date_add('2024-06-15 14:30:00',INTERVAL 10 MONTH);
select date_add('2024-06-15 14:30:00',INTERVAL 10 hour);
select date_add('2024-06-15 14:30:00',INTERVAL 10 week);

select date_format("2024-06-15","%M %d %Y");
select date_format("2024-06-15","%W %M %d %Y");
select name,date_format(dob,"%W %M %e %Y") from persons;

select date_sub(curdate(), INTERVAL 10 DAY);
select day(curdate()); -- current date 14 is printed
select day(dob) from persons; -- date of the given dob

select dayname("2025-03-11"); -- day name of the date
select dayname(curdate());

select dayofmonth("2024-06-14");
select dayofweek(curdate()); -- Friday is 6th day of the week
select dayofyear("2025-06-27"); -- 208th day of the year

select extract(month from "2024-06-14");
select extract(week from "2024-06-14");
select extract(quarter from "2024-06-14");

select from_days(685467);
select from_days(455);
select from_days(775467);
select from_days(24*60*60);

select hour("2017-03-14 09:33:00");
select last_day("2017-07-20");

select makedate(2017,360); -- 360th date of the year 2017 is printed
select monthname("2017-06-15");

select now(); -- current timestamp
select period_add(201706,1); -- adds 1 month
select quarter('2017-06-15'); -- prints the quarter in which this date is present
select second("2017-03-14 09:33:15");
select subdate('2017-06-15',INTERVAL 10 DAY);
select sysdate();
select weekofyear('2017-06-15');
select year('2017-06-15');
select yearweek('2017-06-15'); -- prints 201724 - 24th week of the year 