use trainingdb20;

show tables;

select * from candidates;
select * from candidate_marks;

select * from questions;
select * from question_choices;

select * from employees;

select * from books;
select * from books_topics;

select * from categories;
select * from category_technologies;

select * from bills;
select * from billitems;

select * from contactinfos; -- contactId is Primary Key of contactInfos table
select * from persons;  -- contactId is Foreign Key of persons table

select * from courses;
select * from subjects;
select * from courses_subjects; -- JOIN table to store the course_id (pk of courses) and subject_id (of subjects table)