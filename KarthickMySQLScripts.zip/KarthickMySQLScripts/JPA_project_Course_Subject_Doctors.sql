use trainingdb20;

select * from courses;
select * from courses_subjects;
select * from subjects;

select * from doctors;