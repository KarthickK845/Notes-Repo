use trainingdb19;

select * from contacts;

select * from products_1;

select * from accounts;

select * from players;