package com.ust.ui;

import java.util.Collection;
import java.util.LinkedList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ust.model.Product;

@Controller
@RequestMapping(value="/products")
public class ProductController {
	
	@GetMapping(value="/display")
	public String f1(Model model) {
		Product product = new Product(1089,"Blackberry", 35000.00);
		model.addAttribute("prod", product);
		return "ProductDisplay";
	}
	
	
	@GetMapping(value="/listing")
	public String f2(Model model) {
		Product p1 = new Product(1089, "Blackberry", 35000.00);
		Product p2 = new Product(1090, "Logitech Wireless", 800.00);
		Product p3 = new Product(1091, "Sony TV", 36000.00);
		Product p4 = new Product(1092, "LG Washing Machine", 51000.00);
		Product p5 = new Product(1093, "Acer Laptop", 65000.00);
		
		Collection<Product> products = new LinkedList<>();
		products.add(p1);
		products.add(p2);
		products.add(p3);
		products.add(p4);
		products.add(p5);
		
		model.addAttribute("prods", products);
		
		return "ProductsListing";
	}
	
}
