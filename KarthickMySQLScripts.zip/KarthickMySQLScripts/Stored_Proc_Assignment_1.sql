delimiter //
create procedure retrieveName 
(in personId int, out personName varchar(50))
begin
	select ucase(name) into personName from persons 
    where pid=personId;
end //
delimiter ;

call retrieveName(103,@pname);
select @pname;

    